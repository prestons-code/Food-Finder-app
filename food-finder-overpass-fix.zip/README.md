# Food Finder

Mobile-first restaurant discovery prototype. Includes a landing menu, optional meal/price/cuisine filters, Feeling Lucky (one randomized selection per category), phone geolocation, a 20-mile radius, back navigation, and one-tap Google Maps directions.

## Run

Open `index.html` in a browser, ideally served via localhost or HTTPS (geolocation requires a secure context). For local development from this directory: `python -m http.server 8000`, then visit `http://localhost:8000`.

## Deploy to Vercel

Create a new Vercel project from this directory or a GitHub repository containing these files. Choose **Other** framework, set root directory to the repository root, and leave build command empty. Static `index.html` is the entry point.

## Data / limitation

Uses public OpenStreetMap data through Overpass; browser must permit location and have access to the Overpass API. Public endpoints can be rate-limited, slow or unavailable. Restaurant records generally lack dependable menu pricing. A price filter therefore excludes entries with no explicitly supplied dollar price-range; this can produce few or zero results. Price ranges are not a live menu quote. Breakfast, lunch, etc. are inferred from venue types and tags, not verified operating hours or menus. Restaurant directions open Google Maps; it often offers an option to open in a device map app. In production, integrate a licensed restaurant API and verified menus/prices to offer reliable price-filtered results, and consider a server-side proxy/caching to avoid Overpass usage limits. Restaurant distance is radial (straight-line), not driving distance. No location is stored by this application.

## Choosing a search location

On the home page, users choose **Enter a city, ZIP code, or address** (default) or **Use my current location (GPS)**. GPS permission is only requested when the user explicitly selects GPS and starts a restaurant search. Manual locations are resolved with OpenStreetMap Nominatim when the search runs. Both modes use a 20-mile radius. Open the home page via the back arrow to change the location setting.


## Overpass API fix

Food Finder calls the same-origin `/api/restaurants?lat=...&lon=...` Vercel serverless endpoint for restaurant search, instead of calling public Overpass servers directly from the browser. This avoids browser CORS errors. The server retries alternate Overpass endpoints and responds with a useful error if all are unavailable.

**Deploy to Vercel:** Import this repository as a new Vercel project, or commit `index.html` and `api/restaurants.js` to the existing Vercel-linked repository. Use the **Other** framework preset and deploy the repository root. Do not deploy only the HTML as a static file; the `api/` directory must be deployed too. No API keys required.

**Note:** Browsing `index.html` as a local file will not run the Vercel API route. Test on a Vercel preview or production deployment.
